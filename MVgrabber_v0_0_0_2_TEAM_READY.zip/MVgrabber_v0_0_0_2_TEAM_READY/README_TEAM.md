# MVgrabber – TEAM_READY

## Schnellstart (Firefox via Playwright)

1) Installation (empfohlen):

```bash
python3 install.py
```

2) Start:

```bash
.venv/bin/python main.py
# optional headless:
.venv/bin/python main.py --headless
```

## Welche Dateien brauchst du wirklich?

**Für das Programm selbst (MUSS bleiben):**
- `main.py` – der eigentliche Grabber
- `requirements.txt` – Python-Abhängigkeiten
- `install.py` – installiert deps + Playwright Firefox

**Diese Ordner werden automatisch erzeugt (kannst du löschen, wird neu erstellt):**
- `firefox_profile/` – persistentes Firefox-Profil von Playwright
  - **Kann riesig werden** (Cache, storage, extension data)
  - Löschen ist sicher, du musst dich ggf. neu einloggen
- `Downloads_Serie/` – Downloads (Ausgabedateien)

**Nicht nötig / NICHT ins ZIP committen:**
- Browser-Caches/Profiles wie `.browser_data/` oder große Inhalte in `firefox_profile/cache2/`, `startupCache/`, `storage/` usw.
- `__pycache__/`, `.venv/`, Logfiles, temporäre Downloads

### Wenn du Login/Cookies behalten willst (optional)
Dann **behalte `firefox_profile/`**, aber du kannst trotzdem große Caches löschen (werden neu gebaut):
- sicher löschbar: `firefox_profile/cache2/`, `startupCache/`, `thumbnails/`, große Teile von `storage/` (je nach Site)
- wichtig für Sessions: `cookies.sqlite`, `key4.db`, `cert9.db`, `permissions.sqlite` (je nach Bedarf)

Tipp: Für Team-ZIPs **immer** ein leeres `firefox_profile/` mitliefern (oder gar nicht) – jeder Kollege erstellt seins selbst.

## Team-Workflow

- Siehe `PROJECT_DOCS/progress/TODO.md`
- Session-Log: `PROJECT_DOCS/sessions/LATEST.md`
- Fertige Tasks dokumentieren in `PROJECT_DOCS/progress/DONE.md`

## Support / Debug

- Wenn Playwright fehlt:
  - `pip install playwright`
  - `python -m playwright install firefox`

- Wenn Firefox nicht startet (Linux):
  - `sudo python -m playwright install-deps firefox`

- Wenn Download scheitert:
  - `ffmpeg` muss installiert sein

