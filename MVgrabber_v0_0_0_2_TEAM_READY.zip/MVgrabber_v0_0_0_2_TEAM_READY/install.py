#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""MVgrabber Installer

Ziele:
- Python deps installieren (pip install -r requirements.txt)
- Playwright Firefox-Binaries herunterladen (python -m playwright install firefox)
- optional: Playwright Linux-Systemdeps installieren (install-deps)
- optional: ffmpeg installieren/prüfen

Nutzung:
  python3 install.py

Optional:
  python3 install.py --no-venv
  python3 install.py --skip-deps

Hinweis:
- Der Playwright-Firefox ist NICHT dein System-Firefox, sondern der von Playwright.
  Das ist in der Praxis meistens genau das, was man will (reproduzierbar).
"""

from __future__ import annotations

import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REQ = ROOT / "requirements.txt"
VENV_DIR = ROOT / ".venv"


def run(cmd: list[str], *, check: bool = True, env: dict | None = None) -> int:
    print("\n$", " ".join(cmd))
    p = subprocess.run(cmd, cwd=str(ROOT), env=env)
    if check and p.returncode != 0:
        raise SystemExit(p.returncode)
    return p.returncode


def in_venv() -> bool:
    return getattr(sys, "base_prefix", sys.prefix) != sys.prefix


def venv_python() -> Path:
    if platform.system().lower().startswith("win"):
        return VENV_DIR / "Scripts" / "python.exe"
    return VENV_DIR / "bin" / "python"


def ensure_python_ok():
    if sys.version_info < (3, 10):
        print("❌ Python >= 3.10 wird empfohlen.")
        print(f"   Gefunden: {sys.version}")
        raise SystemExit(1)


def ensure_venv():
    if VENV_DIR.exists():
        return
    print("→ Erzeuge virtuelle Umgebung .venv …")
    run([sys.executable, "-m", "venv", str(VENV_DIR)])


def pip_install(py: Path):
    print("→ Upgrade pip …")
    run([str(py), "-m", "pip", "install", "-U", "pip"])
    print("→ Installiere requirements …")
    run([str(py), "-m", "pip", "install", "-r", str(REQ)])


def playwright_install(py: Path, skip_deps: bool):
    # Browser-Binary
    print("→ Installiere Playwright Firefox …")
    run([str(py), "-m", "playwright", "install", "firefox"])

    # Linux System-Dependencies (libgtk, fonts, etc.)
    if platform.system().lower() == "linux" and not skip_deps:
        print("→ Installiere Playwright Linux deps (falls möglich) …")
        # Das kann root benötigen. Wenn es fehlschlägt, geben wir eine Anleitung.
        try:
            run([str(py), "-m", "playwright", "install-deps", "firefox"], check=True)
        except SystemExit:
            print("\n⚠ Konnte 'playwright install-deps' nicht automatisch ausführen.")
            print("   Falls Firefox nicht startet, führe aus:")
            print("     sudo python -m playwright install-deps firefox")


def ensure_ffmpeg():
    if shutil.which("ffmpeg"):
        print("→ ffmpeg: OK")
        return

    print("\n⚠ ffmpeg fehlt.")
    sysname = platform.system().lower()

    if sysname == "linux":
        # Debian/Kali: apt
        if shutil.which("apt"):
            if os.geteuid() == 0:
                print("→ Installiere ffmpeg via apt (root erkannt) …")
                run(["apt", "update"], check=False)
                run(["apt", "install", "-y", "ffmpeg"], check=False)
            else:
                print("Installiere es so:")
                print("  sudo apt update && sudo apt install -y ffmpeg")
        else:
            print("Installiere ffmpeg über deinen Paketmanager (apt/dnf/pacman).")

    elif sysname.startswith("win"):
        print("Installiere ffmpeg z.B. so:")
        print("  winget install Gyan.FFmpeg")
        print("oder")
        print("  choco install ffmpeg")

    elif sysname == "darwin":
        print("Installiere ffmpeg z.B. so:")
        print("  brew install ffmpeg")


def main():
    import argparse

    ap = argparse.ArgumentParser()
    ap.add_argument("--no-venv", action="store_true", help="Keine .venv erstellen/benutzen")
    ap.add_argument("--skip-deps", action="store_true", help="Playwright install-deps überspringen")
    args = ap.parse_args()

    ensure_python_ok()

    if not REQ.exists():
        print("❌ requirements.txt nicht gefunden.")
        raise SystemExit(1)

    if args.no_venv:
        py = Path(sys.executable)
        print("→ Nutze aktuelles Python:", py)
    else:
        ensure_venv()
        py = venv_python()
        if not py.exists():
            print("❌ Konnte venv-Python nicht finden:", py)
            raise SystemExit(1)

    pip_install(py)
    playwright_install(py, skip_deps=args.skip_deps)
    ensure_ffmpeg()

    print("\n✅ Fertig.")
    if args.no_venv:
        print("Start:")
        print("  python3 main.py")
    else:
        if platform.system().lower().startswith("win"):
            print("Start:")
            print("  .venv\\Scripts\\python.exe main.py")
        else:
            print("Start:")
            print("  .venv/bin/python main.py")


if __name__ == "__main__":
    main()
