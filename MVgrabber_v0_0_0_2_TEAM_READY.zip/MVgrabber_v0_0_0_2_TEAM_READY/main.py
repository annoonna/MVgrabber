#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""MVgrabber – MEDIA FINDER v14 (Playwright Firefox + ffmpeg)

Dieses Skript öffnet eine Staffel-/Episoden-Seite in einem Playwright-gesteuerten
Firefox (persistentes Profil im Ordner ``firefox_profile``) und "snifft" typische
HLS/DASH/MP4-Stream-URLs aus den Netzwerk-Responses.

Wichtig:
- Der Ordner ``firefox_profile`` wird beim ersten Start automatisch erstellt.
  Du musst diesen NICHT in ein ZIP packen (darin stecken sehr große Caches).
- Downloads landen in ``Downloads_Serie``.
"""

import os
import re
import sys
import time
import subprocess
from pathlib import Path
import argparse
import shutil

try:
    from playwright.sync_api import sync_playwright
except ImportError:
    print("❌ Playwright fehlt → pip install playwright")
    print("Dann: playwright install firefox")
    sys.exit(1)

DEFAULT_PROFILE_DIR  = Path.cwd() / "firefox_profile"
DEFAULT_DOWNLOAD_DIR = Path.cwd() / "Downloads_Serie"

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:136.0) Gecko/20100101 Firefox/136.0"

C = {'R':'\033[0m', 'G':'\033[92m', 'Y':'\033[93m', 'B':'\033[94m', 'M':'\033[95m', 'C':'\033[96m'}
def col(t, c): return f"{C.get(c,'')}{t}{C['R']}"

def ensure_dirs(profile_dir: Path, download_dir: Path):
    profile_dir.mkdir(parents=True, exist_ok=True)
    download_dir.mkdir(parents=True, exist_ok=True)

def ensure_ffmpeg_or_die():
    """ffmpeg ist Pflicht für den Download-Schritt."""
    if shutil.which("ffmpeg"):
        return
    print(col("\n❌ ffmpeg wurde nicht gefunden.", 'R'))
    print("\nInstalliere ffmpeg, z.B.:")
    print("  Debian/Kali: sudo apt update && sudo apt install -y ffmpeg")
    print("  Windows:     winget install Gyan.FFmpeg  (oder choco install ffmpeg)")
    print("  macOS:       brew install ffmpeg")
    sys.exit(1)

class MediaGrabber:
    def __init__(self, headless=False, profile_dir=None, download_dir=None, user_agent=None, width=1000, height=700):
        self.pw = None
        self.context = None
        self.found_stream = None
        self.headless = headless
        self.window_width = int(width)
        self.window_height = int(height)
        self.profile_dir = Path(profile_dir) if profile_dir else DEFAULT_PROFILE_DIR
        self.download_dir = Path(download_dir) if download_dir else DEFAULT_DOWNLOAD_DIR
        self.user_agent = user_agent or UA

    def start(self):
        print(col("\n→ Starte Firefox ...", 'Y'))
        self.pw = sync_playwright().start()

        self.context = self.pw.firefox.launch_persistent_context(
            user_data_dir=str(self.profile_dir),
            headless=self.headless,
            args=["--mute-audio", "--no-remote", "--new-instance"],
            viewport={'width': self.window_width, 'height': self.window_height},
            user_agent=self.user_agent,
            bypass_csp=True,
            ignore_https_errors=True,
        )

        print(col(f"→ Firefox bereit ({self.window_width}x{self.window_height})", 'G'))
        print(col("→ Auto-Klick in Fenstermitte aktiviert!", 'C'))
        print("")

    def stop(self):
        if self.context: 
            try: self.context.close()
            except: pass
        if self.pw: 
            self.pw.stop()

    def _sniff_stream(self, response):
        try:
            url = response.url.lower()
            
            is_video = any(x in url for x in [
                '.m3u8', 'master.m3u8', 'playlist.m3u8', 'index.m3u8',
                'chunklist', '.ts', '.mp4', 
                'hls/', '/hls2/', 'manifest.mpd',
                'seg-', 'fragment', 'chunk',
            ])
            
            if not is_video:
                return
            
            is_junk = any(x in url for x in [
                '.js', '.css', '.html', '.json', '.xml',
                '.png', '.jpg', '.jpeg', '.gif', '.svg', '.webp',
                '.woff', '.ttf', '.eot', '.ico',
                'favicon', 'logo', 'thumb', 'preview',
                'static/', 'assets/', 'build/', 'bundle',
                'google', 'analytics', 'facebook', 'doubleclick',
                'ads.', 'tracker', 's.to/build', 's.to/assets',
                'captcha', 'recaptcha'
            ])
            
            if is_junk or len(url) < 60:
                return
            
            if not self.found_stream:
                print(col(f"  ✓ STREAM GEFUNDEN!", 'G'))
                self.found_stream = response.url
                
        except:
            pass

    def get_episodes(self, staffel_url):
        print(col("→ Scanne Episoden ...", 'Y'))
        page = self.context.new_page()
        try:
            page.goto(staffel_url, timeout=60000, wait_until="domcontentloaded")
            time.sleep(4)
            links = page.evaluate(r"""() => Array.from(document.querySelectorAll('a[href*="/episode-"]'))
                .map(a => a.href)
                .filter(href => /\/staffel-\d+\/episode-\d+/.test(href))""")
            unique = sorted(set(links), key=lambda x: int(re.search(r'episode-(\d+)', x).group(1)) if re.search(r'episode-(\d+)', x) else 9999)
            print(col(f"→ {len(unique)} Episoden gefunden", 'G'))
            return unique
        except Exception as e:
            print(col(f"× Scan-Fehler: {e}", 'R'))
            return []
        finally:
            page.close()

    def click_center(self, page, offset_y=0):
        """Klickt in die Mitte des Fensters (oder leicht versetzt)"""
        center_x = self.window_width // 2
        center_y = (self.window_height // 2) + offset_y
        try:
            page.mouse.click(center_x, center_y)
            return True
        except:
            return False

    def grab_episode(self, episode_url, ep_nr):
        print(f"\n{col(f'Episode {ep_nr}', 'B')} → {episode_url.split('/')[-1]}")
        self.found_stream = None

        page = self.context.new_page()
        page.on("response", self._sniff_stream)

        try:
            print("  → Lade Seite ...")
            page.goto(episode_url, timeout=90000, wait_until="domcontentloaded")
            time.sleep(5)
            
            # Automatische Klick-Sequenz
            print("  → Starte Auto-Klick Sequenz ...")
            
            klick_positionen = [
                (0, "Mitte"),
                (50, "Mitte-unten"),
                (-50, "Mitte-oben"),
                (100, "Unten"),
            ]
            
            max_versuche = 8
            versuch = 0
            
            while not self.found_stream and versuch < max_versuche:
                # Wähle Klick-Position (rotierend)
                offset_y, position_name = klick_positionen[versuch % len(klick_positionen)]
                
                # Warte 5 Sekunden
                print(f"  → Warte 5s, dann Klick #{versuch+1} ({position_name}) ...")
                for i in range(5):
                    if self.found_stream:
                        break
                    time.sleep(1)
                
                if self.found_stream:
                    break
                
                # Klick in Fenstermitte
                self.click_center(page, offset_y)
                print(f"  → Klick #{versuch+1} ausgeführt")
                
                # Warte nochmal 5s nach Klick
                for i in range(5):
                    if self.found_stream:
                        break
                    time.sleep(1)
                
                versuch += 1
                
                if not self.found_stream and versuch < max_versuche:
                    print(f"  → Noch kein Stream, nächster Versuch ...")
            
            # Nach Stream-Fund: Warten auf vollständigen Load
            if self.found_stream:
                print(col(f"  ✓ Stream nach Klick #{versuch} gefunden!", 'G'))
                time.sleep(3)
            else:
                print(col("  × Kein Stream nach 8 Versuchen", 'R'))

        except Exception as e:
            print(col(f"× Fehler: {e}", 'R'))
        finally:
            time.sleep(2)
            page.close()

        return self.found_stream

    def download(self, url, filename):
        if not url:
            return False
        path = self.download_dir / filename
        print(col(f"→ Download: {filename}", 'B'))

        cmd = [
            'ffmpeg', '-y',
            '-user_agent', UA,
            '-i', url,
            '-c', 'copy',
            '-bsf:a', 'aac_adtstoasc',
            '-loglevel', 'error',
            '-stats',
            str(path)
        ]

        try:
            subprocess.run(cmd, check=True, timeout=3600)
            
            if path.exists() and path.stat().st_size > 5000000:
                size_mb = path.stat().st_size / (1024*1024)
                print(col(f"✓ OK ({size_mb:.1f} MB)", 'G'))
                return True
            else:
                print(col("× Datei zu klein", 'R'))
                return False
                
        except subprocess.CalledProcessError as e:
            print(col(f"× ffmpeg Fehler: {e.returncode}", 'R'))
            return False
        except subprocess.TimeoutExpired:
            print(col("× Timeout", 'R'))
            return False
        except Exception as e:
            print(col(f"× Fehler: {e}", 'R'))
            return False

def main():
    print(col("\n╔═══════════════════════════════════════════════╗", 'M'))
    print(col("║  MEDIA FINDER v14 – Auto-Klick Mitte         ║", 'M'))
    print(col("║  Klickt automatisch alle 5s in Fenstermitte  ║", 'M'))
    print(col("╚═══════════════════════════════════════════════╝", 'M'))
    
    parser = argparse.ArgumentParser(add_help=True)
    parser.add_argument("--headless", action="store_true", help="Firefox im Headless-Modus starten")
    parser.add_argument("--profile-dir", default=str(DEFAULT_PROFILE_DIR), help="Pfad für persistentes Firefox-Profil")
    parser.add_argument("--download-dir", default=str(DEFAULT_DOWNLOAD_DIR), help="Zielordner für Downloads")
    parser.add_argument("--width", type=int, default=1000, help="Fensterbreite")
    parser.add_argument("--height", type=int, default=700, help="Fensterhöhe")
    args = parser.parse_args()

    profile_dir = Path(args.profile_dir)
    download_dir = Path(args.download_dir)

    ensure_dirs(profile_dir, download_dir)
    ensure_ffmpeg_or_die()

    grabber = MediaGrabber(
        headless=args.headless,
        profile_dir=args.profile_dir,
        download_dir=args.download_dir,
        width=args.width,
        height=args.height,
    )
    grabber.start()

    while True:
        print("\n" + "─"*70)
        url = input("Staffel-URL (q = Ende): ").strip()
        if url.lower() in ('q', 'x', ''):
            break
        if not url.startswith('http'):
            url = 'https://' + url

        episodes = grabber.get_episodes(url)
        if not episodes:
            continue

        if input("Alle laden? (j/n): ").lower() != 'j':
            continue

        erfolg = 0
        fehler = 0
        start_time = time.time()

        for i, ep_url in enumerate(episodes, 1):
            fname = f"Episode_{i:02d}.mp4"
            full_path = grabber.download_dir / fname

            if full_path.exists() and full_path.stat().st_size > 2000000:
                print(col(f"\n→ Episode {i}/{len(episodes)} vorhanden ✓", 'C'))
                erfolg += 1
                continue

            print(col(f"\n{'═'*60}", 'B'))
            print(col(f"  Episode {i}/{len(episodes)}", 'B'))
            print(col(f"{'═'*60}", 'B'))
            
            stream = grabber.grab_episode(ep_url, i)
            
            if stream:
                if grabber.download(stream, fname):
                    erfolg += 1
                else:
                    fehler += 1
            else:
                fehler += 1
            
            time.sleep(2)
        
        elapsed = int(time.time() - start_time)
        
        print(f"\n{col('═'*60, 'M')}")
        print(f"  {col('Fertig:', 'M')} {col(str(erfolg), 'G')} OK | {col(str(fehler), 'R')} Fehler | {elapsed//60}m {elapsed%60}s")
        print(f"{col('═'*60, 'M')}")

    grabber.stop()
    print(col("\n✓ Beendet.", 'G'))

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n⚠ Abgebrochen.")
