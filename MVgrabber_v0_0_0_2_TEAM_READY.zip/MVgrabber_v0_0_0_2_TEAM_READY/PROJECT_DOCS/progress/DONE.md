# DONE – MVgrabber

- 2026-02-26: Repo bereinigt (Browser-Profile/Caches aus ZIP entfernt), `requirements.txt` + `install.py` + Doku hinzugefügt. (ChatGPT)
