# TODO – MVgrabber

## AVAILABLE
- [ ] (Optional) Profil-Cleanup Tool: `python tools/cleanup_profile.py` (löscht nur Cache/Temp)
- [ ] (Optional) Nicht-interaktiver Modus: `--url <staffel-url> --all` (ohne Prompts)
- [ ] (Optional) Kleine PyQt6-GUI: URL Eingabe, Status, Fortschritt, Log

## DONE
- [x] Repo bereinigen + Installer (ChatGPT, 2026-02-26)
