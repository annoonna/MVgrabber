# VISION – MVgrabber

Ziel: Ein kleines Tool, das mit **Playwright Firefox** Streams zuverlässig erkennt (HLS/DASH/MP4) und per **ffmpeg** herunterlädt.

Optional (später): GUI (PyQt6), bessere Fortschrittsanzeige, robustere Episode-Erkennung.
