# MASTER_PLAN – MVgrabber

1) Stabiler CLI-Grabber (Playwright Firefox + ffmpeg) ✅
2) Installer + sauberes Repo ✅
3) Optional:
   - Cleanup-Tool für Profile
   - GUI (PyQt6)
   - Batch-Modus ohne Eingaben
