# LATEST Session Log

Datum: 2026-02-26

## Ziel
Projekt/ZIP bereinigen und installierbar machen, ohne riesige Browser-Profile mitzuschleppen.

## Änderungen
- Entfernt: `.browser_data/` und riesige Inhalte aus `firefox_profile/` (Caches)
- Hinzugefügt: `requirements.txt`, `install.py`, `README_TEAM.md`, `BRIEF_AN_KOLLEGEN.md`, `PROJECT_DOCS/*`
- Gehärtet: `main.py` (ffmpeg-Check + optionale CLI-Args)

## Hinweis
`firefox_profile/` ist **Runtime-State** (kann sehr groß werden). Für Team-ZIPs nicht mitschicken.
