# MVgrabber – Brief an Kollegen

Stand: **v0.0.0.2 (TEAM_READY)**

## Was wurde gemacht
- ZIP bereinigt: riesige Browser-Profile/Caches entfernt (war >300 MB), damit das Projekt sauber teilbar bleibt.
- `requirements.txt` hinzugefügt (Playwright).
- `install.py` hinzugefügt:
  - installiert requirements
  - lädt Playwright-Firefox herunter
  - versucht unter Linux optional `install-deps`
  - prüft/unterstützt ffmpeg
- `README_TEAM.md` + `PROJECT_DOCS/*` Basis-Struktur hinzugefügt.
- `main.py` minimal gehärtet:
  - ffmpeg-Check
  - optionale CLI-Argumente (`--headless`, `--profile-dir`, `--download-dir`, `--width/--height`)

## Nächster sinnvoller Task
- Optional: "Profil-Cleanup" Script (Caches automatisch löschen) oder GUI (PyQt6) – aber nur, wenn gewünscht.

